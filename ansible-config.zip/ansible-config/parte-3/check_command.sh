snmpget -v 3 -u vagrant -l authPriv -a SHA -A vagrant1234 -x AES -X vagrant1234 10.0.125.3 SNMPv2-MIB::sysUpTime.0
